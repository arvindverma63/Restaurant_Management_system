<?php include("header.php"); ?>
<body>
 <?php include("navbar.php"); ?>
 <style type="text/css">
   body{
    /*background: url("images/bg.jpg");
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;*/
    background-color: #f5f5f5;
  }
  .container{
        margin-top: 10%;
        
    }
    @media (max-width: 700px){
      .container table tr{
      font-size: 10px;
    }
    }
 </style>

 <div class="container" style="overflow-x: auto">
    <div class="input-group mb-3">
  <div class="form-outline" data-mdb-input-init>
    <input type="search" id="form1" class="form-control" />
    <label class="form-label" for="form1">Search</label>
  </div>
  <button type="button" class="btn btn-primary" data-mdb-ripple-init>
    <i class="fas fa-search"></i>
  </button>
</div>
    <table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Table Number</th>
      <th scope="col">Order Id </th>
      <th scope="col">Item Names</th>
      <th scope="col">Time</th>
    </tr>
  </thead>
  <tbody id="list">
    
  </tbody>
</table>
 </div>

 </body>
 
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.umd.min.js"
></script>
<script type="text/javascript">
  fetch("fetch-data/fetch-order.php")
  .then(response=>response.text())
  .then((data)=>{
    document.getElementById("list").innerHTML = data;
  })
</script>