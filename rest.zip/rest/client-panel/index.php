<?php include("header.php"); ?>
<?php include("../database/config.php"); ?>

<body>
    <?php include("navbar.php"); ?>

    <style type="text/css">
        body {
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
        }

        #category {
            width: 80%;
            margin-left: 10%;
        }

        .btn {
            width: 100%;
            margin-left: 5%;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .grid-container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: none;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        #image{
            
        }

        .card-header {
            width: 100%;
        }

        .card-title {
            font-size: 18px;
            font-weight: bold;
        }

        .card-body {
            text-align: center;
        }

        @media (max-width: 992px) {
            .grid-container {
                grid-template-columns: repeat(2, 1fr);
            }

            .btn {
                width: 100%;
                margin-left: 0;
            }
        }

        @media (max-width: 576px) {
            .grid-container {
                grid-template-columns: repeat(2, 1fr);
                gap: 10px;
            }

            .card {
                padding: 10px;
            }

            .card-title {
                font-size: 16px;
            }

            .btn {
                width: 100%;
                margin-left: 0;
            }
        }
    </style>

    <section class="h-100" style="background-color: #f5f5f5;">
        <div class="container h-100 py-5">
            <div class="grid-container">
                <?php 
                $query2 = "SELECT * FROM category";
                $result2 = mysqli_query($conn, $query2);
                if (mysqli_num_rows($result2) > 0) {
                    while ($row2 = mysqli_fetch_assoc($result2)) {
                        // Assuming 'image_path' is the column that stores the image path in your database
                        $imagePath = $row2['image_path'];
                        echo '<a href="menu.php?cat='.$row2['category'].'">
                        <div class="card mb-3" >
                            <div class="card-header">
                                <center><h5 class="card-title">'.$row2['category'].'</h5></center>
                            </div>
                            <div class="card-body" style="background-image: url(\''.$imagePath.'\'); background-size: cover; background-position: center; height: 130px; width: 100%;">
                                
                            </div>
                        </div></a>';
                    }
                } else {
                    echo '<center>No category found</center>';
                }
                ?>

            </div>
        </div>
    </section>
</body>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.umd.min.js"></script>
