<?php include("../database/config.php"); ?>
<?php include("header.php"); ?>

<?php
   $category = $_GET['cat'];
?>
<style type="text/css">
    body {
        background-color: #f5f5f5;
        font-family: Arial, sans-serif;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    .grid-container {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
    }

    .card {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border: none;
        padding: 20px;
        background-color: white;
        border-radius: 8px;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .card img {
        width: 100px;
        height: 100px;
        object-fit: cover;
        border-radius: 8px;
        margin-bottom: 10px;
    }

    .card-content {
        text-align: center;
    }

    .lead {
        font-size: 16px;
        margin: 0 0 10px 0;
    }

    .price {
        font-size: 18px;
        font-weight: bold;
        color: #333;
    }

    @media (max-width: 992px) {
        .grid-container {
            grid-template-columns: repeat(2, 1fr);
        }

        .card img {
            width: 80px;
            height: 80px;
        }
    }

    @media (max-width: 576px) {
        .grid-container {
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }

        .card img {
            width: 60px;
            height: 60px;
        }

        .lead {
            font-size: 14px;
        }

        .price {
            font-size: 16px;
        }
    }
</style>

<body>
    <?php include("navbar.php"); ?>

    <div class="container h-100 py-5">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3 class="fw-normal mb-0 text-black">Food Items</h3>
                </div>

                <div class="grid-container">
                    <?php 
                    $query = "SELECT * FROM menu WHERE category = '$category' AND status = '1'";
                    $result = mysqli_query($conn, $query);
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $itemId = $row["s_no"];
                            $itemName = $row["item_name"];
                            $price = $row["price"];
                            echo '
                            <div class="card rounded-3 mb-4">
                                <img src="../'.$row["image"].'" alt="Food Icon">
                                <div class="card-content">
                                    <p class="lead fw-normal mb-2">'.$itemName.'</p>
                                    <h5 class="price">Rs. '.$price.' /piece</h5>
                                </div>
                            </div>';
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.umd.min.js"></script>
</body>
</html>
