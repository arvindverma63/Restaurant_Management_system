<?php
header('Content-Type: application/json');
include("../database/config.php"); // Include your database configuration file

// Get the raw POST data
$data = json_decode(file_get_contents('php://input'), true);
$order_id = "OR" . time();
$current_time = date('Y-m-d H:i:s'); // Get the current timestamp

if ($data) {
    // Prepare an array to collect responses for each order
    $response = [];

    // Create an array to hold all items
    $allItems = [];

    // Process each order item
    foreach ($data as $order) {
        $itemName = $order['item_name'];
        $quantity = $order['quantity'];
        $price = $order['price'];
        $tableNo = $order['table_no'];

        // Append the item details to the allItems array
        $allItems[] = [
            'item_name' => $itemName,
            'quantity' => $quantity,
            'price' => $price
        ];
    }

    // Convert the items array to a JSON string
    $items = json_encode($allItems);

    // Prepare the SQL statement for inserting order data
    $stmt = $conn->prepare("INSERT INTO orders (items, table_no, order_id, `time`) VALUES (?, ?, ?, ?)");
    if ($stmt === false) {
        $response = [
            'status' => 'error',
            'message' => 'Failed to prepare statement',
            'error' => $conn->error
        ];
        echo json_encode($response);
        exit();
    }

    $stmt->bind_param("ssss", $items, $tableNo, $order_id, $current_time);

    // Execute the prepared statement
    if ($stmt->execute()) {
        $response = [
            'status' => 'success',
            'message' => 'Order processed successfully',
            'data' => $data
        ];
    } else {
        $response = [
            'status' => 'error',
            'message' => 'Failed to process order',
            'error' => $stmt->error
        ];
    }

    // Close the statement
    $stmt->close();

    // Send the response back to the client
    echo json_encode($response);
} else {
    $response = [
        'status' => 'error',
        'message' => 'Invalid data received'
    ];

    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
