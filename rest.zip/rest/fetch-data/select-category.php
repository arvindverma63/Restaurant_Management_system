<?php 
include('../database/config.php');

$response = array();
$query = "SELECT * FROM category";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $response[] = $row['category']; // Append each category to the response array
    }
}

echo json_encode($response);
?>
