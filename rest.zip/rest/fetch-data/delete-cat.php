<?php 
   include("../database/config.php");
   $s_no = $_GET['s_no'];
   $query = "DELETE FROM category WHERE s_no='$s_no'";
   $result = mysqli_query($conn,$query);
   if($result){
   	echo "<script>alert('Delete Successfully')</script>";
   	header("Location: ../category.php");
   }
?>