<?php
// fetch-data/add-menu-category.php
include('../database/config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if all required data is present
    if (!isset($_POST['categoryName']) || !isset($_FILES['menuImage'])) {
        $response = array(
            'status' => 'error',
            'message' => 'Category name or image is missing.'
        );
        echo json_encode($response);
        exit;
    }

    // Sanitize and validate input
    $categoryName = htmlspecialchars($_POST['categoryName']);

    // File upload handling
    $targetDir = "../category-img/";
    $targetFile = $targetDir . basename($_FILES["menuImage"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["menuImage"]["tmp_name"]);
    if($check === false) {
        $response = array(
            'status' => 'error',
            'message' => 'File is not an image.'
        );
        echo json_encode($response);
        exit;
    }

    // Check file size
    if ($_FILES["menuImage"]["size"] > 500000) {
        $response = array(
            'status' => 'error',
            'message' => 'Sorry, your file is too large.'
        );
        echo json_encode($response);
        exit;
    }

    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        $response = array(
            'status' => 'error',
            'message' => 'Sorry, only JPG, JPEG, PNG & GIF files are allowed.'
        );
        echo json_encode($response);
        exit;
    }

    // Upload file
    if (move_uploaded_file($_FILES["menuImage"]["tmp_name"], $targetFile)) {
        // File uploaded successfully, now insert into database
        // Assuming you have a database connection established

        // Insert into database
        $sql = "INSERT INTO category (category, image_path) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $categoryName, $targetFile); // Assuming 'image_path' column stores the file path
        if ($stmt->execute()) {
            // Insert successful
            $response = array(
                'status' => 'success',
                'message' => 'Category added successfully'
            );
        } else {
            // Insert failed
            $response = array(
                'status' => 'error',
                'message' => 'Error inserting category into database'
            );
        }

        $stmt->close();
        $conn->close();
    } else {
        // File upload failed
        $response = array(
            'status' => 'error',
            'message' => 'Sorry, there was an error uploading your file.'
        );
    }

    // Respond with JSON
    echo json_encode($response);
}
?>
