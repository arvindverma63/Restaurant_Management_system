<?php
include("../database/config.php");

$response = array();

// Retrieve and decode JSON input
$input = json_decode(file_get_contents("php://input"), true);

// Retrieve and sanitize inputs
$fname = mysqli_real_escape_string($conn, $input["efname"]);
$lname = mysqli_real_escape_string($conn, $input["elname"]);
$email = mysqli_real_escape_string($conn, $input["eemail"]);
$phone = mysqli_real_escape_string($conn, $input["ephone"]);
$address = mysqli_real_escape_string($conn, $input["eaddress"]);
$id = mysqli_real_escape_string($conn, $input["eid"]); // Assuming the user ID is passed as well

// Prepare the SQL query using prepared statements
$query1 = "UPDATE user_details SET fname = ?, lname = ?, email = ?, phone = ?, address = ? WHERE u_id = ?";
$query2 = "UPDATE users SET email = ? WHERE u_id = ?";

$stmt1 = $conn->prepare($query1);
$stmt2 = $conn->prepare($query2);

if ($stmt1 && $stmt2) {
    $stmt1->bind_param("ssssss", $fname, $lname, $email, $phone, $address, $id);
    $stmt2->bind_param("ss", $email, $id);
    
    // Execute the queries and check for success
    if ($stmt1->execute() && $stmt2->execute()) {
        $response["status"] = "success";
        $response["message"] = "User details updated successfully.";
    } else {
        $response["status"] = "error";
        $response["message"] = "Failed to update user details.";
    }

    $stmt1->close();
    $stmt2->close();
} else {
    $response["status"] = "error";
    $response["message"] = "Failed to prepare the SQL statements.";
}

echo json_encode($response);
$conn->close();
?>
