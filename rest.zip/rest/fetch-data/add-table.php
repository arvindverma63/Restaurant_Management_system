<?php 
include("../database/config.php");
include("../phpqrcode/qrlib.php");

// Ensure the request method is POST
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['qr'])) {
        $table_num = $_POST['qr'];

        // Validate the input
        if (empty($table_num)) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Table number is required'
            ]);
            exit();
        }

        // Ensure the uploads directory exists
        $upload_dir = 'fetch-data/uploads/';
        if (!is_dir($upload_dir) && !mkdir($upload_dir, 0777, true) && !is_dir($upload_dir)) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Failed to create upload directory'
            ]);
            exit();
        }

        $file_name = $upload_dir . "qr" . time() . ".png";
        $qr_content = 'https://rest.avyuktcoretechnologies.com/client-panel/';

        // Generate the QR code
        QRcode::png($qr_content, $file_name);

        // Check if the QR code file was created
        if (!file_exists($file_name)) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Failed to generate QR code'
            ]);
            exit();
        }

        // Prepare the SQL statement to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO qr_table (table_no, qr) VALUES (?, ?)");
        $stmt->bind_param("ss", $table_num, $file_name);

        if ($stmt->execute()) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Table number added successfully'
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Failed to add table number to the database'
            ]);
        }

        $stmt->close();
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid input'
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method'
    ]);
}
?>
