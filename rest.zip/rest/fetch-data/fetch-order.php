<?php
include("../database/config.php"); // Include your database configuration file

$query = "SELECT * FROM orders ORDER BY s_no DESC";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    echo '<table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">S. No</th>
                    <th scope="col">Table No</th>
                    <th scope="col">Order ID</th>
                    <th scope="col">Items</th>
                    <th scope="col">Time</th>
                </tr>
            </thead>
            <tbody>';
    
    while ($row = mysqli_fetch_assoc($result)) {
        $orderId = $row['order_id'];
        $tableNo = $row['table_no'];
        $items = $row['items'];
        $time = $row['time'];
        $s_no = $row['s_no'];
        
        // Check if $items is not null and decode the JSON string to get the items array
        if ($items !== null) {
            $itemsArray = json_decode($items, true);

            // Initialize a variable to hold item details as a string
            $itemDetails = '';

            // Iterate over each item and add its details to the itemDetails string
            foreach ($itemsArray as $item) {
                $itemDetails .= $item['item_name'] . ' (' . $item['quantity'] . '), ';
            }

            // Remove the trailing comma and space
            $itemDetails = rtrim($itemDetails, ', ');
        } else {
            // If $items is null, set itemDetails to an empty string
            $itemDetails = '';
        }

        echo '<tr>
                <th scope="row">' . $s_no . '</th>
                <td>' . $tableNo . '</td>
                <td>' . $orderId . '</td>
                <td>' . $itemDetails . '</td>
                <td>' . $time . '</td>
              </tr>';
    }

    echo '</tbody></table>';
} else {
    echo "No orders found.";
}

mysqli_close($conn);
?>
