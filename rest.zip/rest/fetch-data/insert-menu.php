<?php 
include("../database/config.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the item name, price, and category from the POST request
    $item_name = $_POST['item_name'];
    $price = $_POST['price'];
    $category = $_POST['category'];

    // Validate inputs
    if (empty($item_name) || empty($price) || empty($category)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Item name, price, and category are required'
        ]);
        exit();
    }

        $file_tmp = $_FILES['item_image']['tmp_name'];
        $file_name = basename($_FILES['item_image']['name']);
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));


        // Generate a unique file name to prevent overwriting
        $new_file_name = uniqid() . '.' . $file_ext;
        $upload_dir = 'uploads'; // Ensure this directory exists and is writable

        // Ensure the upload directory exists
        if (!is_dir($upload_dir) && !mkdir($upload_dir, 0777, true)) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Failed to create upload directory'
            ]);
            exit();
        }

        // Create the upload path
        $upload_path = $upload_dir . "/" . $new_file_name;

        // Move the uploaded file to the desired directory
        if (move_uploaded_file($file_tmp, $upload_path)) {
            // Prepare the SQL statement to prevent SQL injection
            $stmt = $conn->prepare("INSERT INTO menu (item_name, price, image, category) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sdss", $item_name, $price, $upload_path, $category);

            if ($stmt->execute()) {
                echo json_encode([
                    'status' => 'success',
                    'message' => 'Item added successfully',
                    'item_name' => $item_name,
                    'price' => $price,
                    'file_name' => $new_file_name
                ]);
            } else {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Failed to add item to database',
                    'error' => $stmt->error // Add error message from statement
                ]);
            }

            $stmt->close();
        } else {
            // File upload failed
            echo json_encode([
                'status' => 'error',
                'message' => 'Failed to upload file. Check permissions on the uploads directory.',
                'debug_info' => [
                    'file_tmp' => $file_tmp,
                    'upload_path' => $upload_path,
                    'is_writable' => is_writable($upload_dir)
                ]
            ]);
        }
    } else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method'
    ]);
}
?>
