<?php 
include("../database/config.php");


 $file_name = $_FILES['image']['name'];
 $tempname = $_FILES['image']['tmp_name'];
  $folder = "uploads/".$file_name;

 move_uploaded_file($tempname, $folder);


?>