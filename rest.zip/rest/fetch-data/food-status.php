<?php
include('../database/config.php');

// Read the JSON data from the request body
$input = file_get_contents("php://input");
$data = json_decode($input, true);
$response = array();

if (isset($data['switch']) && isset($data['id'])) {
    $status = $data['switch'] === 'on' ? 1 : 0; // Assuming 'on' is 1 and 'off' is 0
    $id = $data['id'];

    // Prepare the SQL update query
    $query = "UPDATE menu SET status = ? WHERE s_no = ?";

    // Prepare the statement
    if ($stmt = $conn->prepare($query)) {
        // Bind parameters
        $stmt->bind_param("ii", $status, $id);

        // Execute the statement
        if ($stmt->execute()) {
            $response = ['data' => 'success'];
        } else {
            $response = ['data' => 'error', 'message' => 'Failed to execute query'];
        }

        // Close the statement
        $stmt->close();
    } else {
        $response = ['data' => 'error', 'message' => 'Failed to prepare statement'];
    }
} else {
    $response = ['data' => 'error', 'message' => 'Invalid input'];
}

// Close the database connection
$conn->close();

// Send the response as JSON
echo json_encode($response);
?>
