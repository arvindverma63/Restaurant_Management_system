<?php include("header.php"); ?>
<?php include("database/config.php"); ?>
<body>
 <?php include("navbar.php"); ?>
 <style type="text/css">
   body{
    /*background: url("images/bg.jpg");
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;*/
    background-color: #f5f5f5;
  }
  #category{
    width: 80%;
    margin-left: 10%;
  }
 </style>

 <div class="container">
    <section class="h-100" style="background-color: #f5f5f5;">
  <div class="container h-100 py-5">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-10">
        <?php 
        $query2 = "SELECT * FROM category";
        $result2 = mysqli_query($conn,$query2);
        if(mysqli_num_rows($result2)>0){
          while($row2 = mysqli_fetch_assoc($result2)){
            echo '<div class="card mb-3">
  <div class="card-header">
    Category
  </div>
  <div class="card-body">
    <h5 class="card-title">'.$row2['category'].'</h5>
    <p class="card-text"></p>
    <a href="menu.php?cat='.$row2['category'].'" class="btn btn-primary">Open</a>
    <a href="fetch-data/delete-cat.php?s_no='.$row2['s_no'].'" class="btn btn-danger">Delete</a>
  </div>
</div>';
          }
        }
        else{
          echo '<center>No category found</center>';
        }
        ?>
        

        

        

        <!-- <div class="card mb-4">
          <div class="card-body p-4 d-flex flex-row">
            <div data-mdb-input-init class="form-outline flex-fill">
              <input type="text" id="form1" class="form-control form-control-lg" />
              <label class="form-label" for="form1">Discound code</label>
            </div>
            <button  type="button" data-mdb-button-init data-mdb-ripple-init class="btn btn-outline-warning btn-lg ms-3">Apply</button>
          </div>
        </div>

        <div class="card">
          <div class="card-body">
            <button  type="button" data-mdb-button-init data-mdb-ripple-init class="btn btn-warning btn-block btn-lg">Proceed to Pay</button>
          </div>
        </div> -->

      </div>
    </div>
  </div>
</section>
 </div>

 </body>
 
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.umd.min.js"
></script>