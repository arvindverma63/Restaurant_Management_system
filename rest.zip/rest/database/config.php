<?php
  $host = "localhost";
  $user = "root";
  $pass = "";
  $db = "s_rest";

  $conn = mysqli_connect($host,$user,$pass,$db);
 
?>