<?php include("header.php"); ?>
<body>
 <?php include("navbar.php"); ?>

 <style>
  body{
    /*background: url("images/bg.jpg");
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;*/
    background-color: #f5f5f5;
  }
    .container{
        margin-top: 10%;
        display: flex;
        flex-direction: row;
    }
    #card1{
        height: 40%;
        width: 40%;
        margin-left: 10%;
    }
    #card2{
        height: 40%;
        width: 40%;
        margin-left: 10%;
    }
    #img{
        width: 50%;
    }
    @media (max-width: 700px){
        .container{
            flex-direction: column;
            margin-top: 8%;
/*            margin-left: 10%;*/
        }
        #card1{
        height: 80%;
        width: 80%;
        margin-left: 10%;
    }

    #menu-btn{
      margin-top: 10px;
    }
    #card2{
        margin-top: 8%;
        height: 80%;
        width: 80%;
        margin-left: 10%;
    }
  
    }
 </style>

  

<!-- Modal 1 -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">ADD Food Item to Menu</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="addItemForm" action="#" method="post" enctype="multipart/form-data">
        <select class="form-select mb-3" id="select-cat" name="category" aria-label="Default select example" required>
            
        </select>
        <div class="mb-3">
            <label for="item_name" class="form-label">Item Name</label>
            <input type="text" class="form-control" id="item_name" name="item_name" required>
        </div>
        <div class="mb-3">
            <label for="price" class="form-label">Price</label>
            <input type="number" class="form-control" id="price" name="price" required>  
        </div>
        <div class="mb-3">
            <label class="form-label" for="item_image">Upload Item Image</label>
            <input type="file" class="form-control" id="item_image" name="item_image" required>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
   

      </div>
      <div class="modal-footer">
        <!--<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
        <!--<button type="submit" class="btn btn-primary" id="add-item" form="addItemForm">Save changes</button>-->
      </div>
       </form>
        <?php
        include('database/config.php');
    // Retrieve form data
    $category = $_POST['category'];
    $itemName = $_POST['item_name'];
    $price = $_POST['price'];
    $itemImage = $_FILES['item_image'];

    // Check if file was uploaded without errors
    if ($itemImage['error'] == 0) {
        $imageName = $itemImage['name'];
        $imageTmpName = $itemImage['tmp_name'];
        $imageSize = $itemImage['size'];
        $imageType = $itemImage['type'];
        $imageExt = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));

        // Define allowed file types
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];

        // Validate file type
        if (in_array($imageExt, $allowed)) {
            // Define the upload path
            $uploadDir = 'images/';
            $uploadFilePath = $uploadDir . basename($imageName);

            // Move the file to the upload directory
            if (move_uploaded_file($imageTmpName, $uploadFilePath)) {
                // Prepare an SQL statement to insert the data into the database
                $stmt = $conn->prepare("INSERT INTO menu (category, item_name, price, image) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssds", $category, $itemName, $price, $uploadFilePath);

                // Execute the statement
                if ($stmt->execute()) {
                    echo "<script>alert('New record created successfully');</script>";
                    
                } else {
                    echo "Error: " . $stmt->error;
                }

                // Close the statement
                $stmt->close();
            } else {
                echo "Error uploading the file.";
            }
        } else {
            
        }
    } else {
        echo "Error: " . $itemImage['error'];
    }

?>
    </div>
  </div>
</div>
<!-- Modal 2 -->
<div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Add Table</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="add-table-form">
          <div class="mb-3">
            <label for="table-num" class="form-label">Table Number</label>
            <input type="number" class="form-control" name="qr" id="table-num" aria-describedby="tableHelp">
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" id="add-table" class="btn btn-primary" form="add-table-form">Add Table</button>
      </div>
    </div>
  </div>
</div>

<script>
document.getElementById('add-table-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const tableNum = document.getElementById('table-num').value;
    
    fetch('fetch-data/add-table.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({ qr: tableNum })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data);
        if (data.status === 'success') {
            alert('Table number added successfully');
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
    });
});
</script>


<!--- modal 3 -->


<!-- Modal -->
<!-- Modal -->
<div class="modal fade" id="category" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Menu Category</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="add-menu-category-form">
          <div class="input-group mb-3">
            <span class="input-group-text" id="inputGroup-sizing-default">Category Name</span>
            <input type="text" class="form-control" id="menu-category" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
          </div>
          <div class="input-group mb-3">
            <input type="file" class="form-control" id="menu-image" name="menu-image">
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="submit-menu-category">Save changes</button>
      </div>
    </div>
  </div>
</div>

<script>
    document.getElementById('submit-menu-category').addEventListener('click', function(event) {
    event.preventDefault();

    const categoryName = document.getElementById('menu-category').value;
    const menuImage = document.getElementById('menu-image').files[0]; // Get the file object

    if (!categoryName || !menuImage) {
        alert('Category name or image is missing.');
        return;
    }

    const formData = new FormData();
    formData.append('categoryName', categoryName);
    formData.append('menuImage', menuImage);

    fetch('fetch-data/fetch-category.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data);
        if (data.status === 'success') {
            alert('Menu category added successfully');
            document.getElementById('category').reset(); // Reset form if needed
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
    });
});
                                              
</script>





 <div class="container">
 <div class="card" id="card1">
  <div class="bg-image hover-overlay" data-mdb-ripple-init data-mdb-ripple-color="light">
    <img src="images/menu.gif" class="img-fluid" id="img"/>
    <a href="#!">
      <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
    </a>
  </div>
  <div class="card-body">
    <h5 class="card-title">Add Menu</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
          Add Menu
        </button>
<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" id="menu-btn" data-bs-toggle="modal" data-bs-target="#category">
  Add Category
</button>
  </div>
</div>
<div class="card" id="card2">
  <div class="bg-image hover-overlay" data-mdb-ripple-init data-mdb-ripple-color="light">
    <img src="images/table.gif" class="img-fluid" id="img"/>
    <a href="#!">
      <div class="mask" style="background-color: rgba(251, 251, 251,  0.15);"></div>
    </a>
  </div>
  <div class="card-body">
    <h5 class="card-title">Create Qr</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
     <!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal2">
  Create QR
</button>
  </div>
</div>

 </div>

 <script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.umd.min.js"
></script>

</body>

 <!--<script type="text/javascript" src="js/table.js"></script> -->
<!--<script type="text/javascript" src="js/insert.js"></script>-->

<!--<script type="text/javascript" src="js/fetch-category.js"></script>-->
<script type="text/javascript" src="js/select-category.js"></script>

</html>