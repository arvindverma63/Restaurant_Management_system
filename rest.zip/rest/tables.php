<?php include("header.php"); ?>
<?php include("database/config.php"); ?>
<body>
 <?php include("navbar.php"); ?>
 <style>
  body{
    /*background: url("images/bg.jpg");
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;*/
    background-color: #f5f5f5;
  }
    .card{
        margin-left: 10%;
        margin-right: 10%;
        margin-top: 5%;
    }
    .card-title{
        margin-left: 3%;
        margin-top: 2%;
    }
    #qr-modal{
        margin-left: 80%;
    }
    #qr-image{
        margin-left: 20%;
    }
    #delete{
        margin-left: 90%;
    }
    @media (max-width: 700px){
        #qr-modal{
        margin-left: 60%;
    }
    }
   
 </style>


<!-- <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
  <div class="mb-3" id="qr-image">
    <img src="images/qr.png">
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div> -->

<?php
$query = "SELECT * FROM qr_table";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $modalId = 'modal' . $row["table_no"];
        echo '
        <div class="modal fade" id="' . $modalId . '" tabindex="-1" aria-labelledby="' . $modalId . 'Label" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="' . $modalId . 'Label">QR Code NO ' . $row["table_no"] . '</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3" id="qr-image">
                            <img src="fetch-data/' . $row["qr"] . '" class="img-fluid" alt="QR Code">
                            <h3>Table No: ' . $row["table_no"] . '</h3>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <h5 class="card-title">Table ' . $row["table_no"] . '</h5>
            <div class="card-body">
                <p>This is QR No. ' . $row["table_no"] . '</p>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#' . $modalId . '">
                    Get QR
                </button>
                <div class="col-md-1 col-lg-1 col-xl-1 text-end" id="delete">
                <a href="fetch-data/delete-table.php?s_no='.$row["s_no"].'" class="text-danger"><i class="fas fa-trash fa-lg"></i></a>
              </div>
            </div>
        </div>';
    }
}
else{
  echo '<center>There is no qr now </center>';
}
?>




<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.umd.min.js"
></script>
 </body>