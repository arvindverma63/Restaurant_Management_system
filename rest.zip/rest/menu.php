<?php include("header.php"); ?>
<?php include("database/config.php"); ?>
<body>
 <?php include("navbar.php"); ?>
 <style type="text/css">
   body{
    /*background: url("images/bg.jpg");
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;*/
    background-color: #f5f5f5;
  }
  #category{
    width: 80%;
    margin-left: 10%;
  }
   body {
        background-color: #f5f5f5;
        font-family: Arial, sans-serif;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    .grid-container {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
    }

    .card {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border: none;
        padding: 20px;
        background-color: white;
        border-radius: 8px;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .card img {
        width: 100px;
        height: 100px;
        object-fit: cover;
        border-radius: 8px;
        margin-bottom: 10px;
    }

    .card-content {
        text-align: center;
    }

    .lead {
        font-size: 16px;
        margin: 0 0 10px 0;
    }

    .price {
        font-size: 18px;
        font-weight: bold;
        color: #333;
    }

    @media (max-width: 992px) {
        .grid-container {
            grid-template-columns: repeat(2, 1fr);
        }

        .card img {
            width: 80px;
            height: 80px;
        }
    }

@media (max-width: 576px) {
    .grid-container {
        grid-template-columns: repeat(2, 1fr); /* Change from repeat(1, 1fr) to repeat(2, 1fr) */
        gap: 10px;
    }

    .card img {
        width: 160px;
        height: 160px;
    }

    .lead {
        font-size: 14px;
    }

    .price {
        font-size: 16px;
    }
}

 </style>


  <div class="container h-100 py-5">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-10">
        
        

        <?php 
        $category = $_GET['cat'];
          $query = "SELECT * FROM menu Where category = '$category'";
          $result = mysqli_query($conn,$query);
          
          if(mysqli_num_rows($result)>0){
            echo '<div class="d-flex justify-content-between align-items-center mb-4">
          <h3 class="fw-normal mb-0 text-black">Food Items</h3>
          <div>
            <!-- <p class="mb-0"><span class="text-muted">Sort by:</span> <a href="#!" class="text-body">price <i
                  class="fas fa-angle-down mt-1"></i></a></p> -->
          </div>
        </div>';
            while($row = mysqli_fetch_assoc($result)){
              echo '<div class="card rounded-3 mb-4">
          <div class="card-body p-4">
            <div class="row d-flex justify-content-between align-items-center">
              <div class="col-md-2 col-lg-2 col-xl-2">
                <img
                  src="'.$row["image"].'"
                  class="img-fluid rounded-3">
              </div>
              <div class="col-md-3 col-lg-3 col-xl-3">
                <p class="lead fw-normal mb-2">'.$row["item_name"].'</p>
                
              </div>';

              if($row['status']=="1"){
                echo '<div class="col-md-3 col-lg-3 col-xl-2 d-flex">
                <div class="form-check form-switch">
                    <input class="form-check-input" data-id='.$row["s_no"].' type="checkbox" role="switch" id="check-box" checked/>
                    <label class="form-check-label" for="check-box">on/off</label>
                </div>
              </div>';
              }
              else{
                echo '<div class="col-md-3 col-lg-3 col-xl-2 d-flex">
                <div class="form-check form-switch">
                    <input class="form-check-input" data-id='.$row["s_no"].' type="checkbox" role="switch" id="check-box" />
                    <label class="form-check-label" for="check-box">on/off</label>
                </div>
              </div>';
              }
              
              echo '<div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
                <h5 class="mb-0">Rs. '.$row["price"].' per piece</h5>
              </div>
              <div class="col-md-1 col-lg-1 col-xl-1 text-end">
                <a href="fetch-data/delete-menu.php?s_no='.$row["s_no"].'" class="text-danger"><i class="fas fa-trash fa-lg"></i></a>
              </div>
            </div>
          </div>
        </div>';
            }
            
          }
          else{
            echo "<center>Now There is no menu.</center>";
          }
         ?>

        

        <!-- <div class="card mb-4">
          <div class="card-body p-4 d-flex flex-row">
            <div data-mdb-input-init class="form-outline flex-fill">
              <input type="text" id="form1" class="form-control form-control-lg" />
              <label class="form-label" for="form1">Discound code</label>
            </div>
            <button  type="button" data-mdb-button-init data-mdb-ripple-init class="btn btn-outline-warning btn-lg ms-3">Apply</button>
          </div>
        </div>

        <div class="card">
          <div class="card-body">
            <button  type="button" data-mdb-button-init data-mdb-ripple-init class="btn btn-warning btn-block btn-lg">Proceed to Pay</button>
          </div>
        </div> -->

      </div>
    </div>
  </div>
 </body>
 
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.2.0/mdb.umd.min.js"
></script>
<script>
 document.addEventListener("DOMContentLoaded", function() {
    var checkboxes = document.querySelectorAll(".form-check-input");
    
    checkboxes.forEach(function(checkbox) {
        checkbox.addEventListener("change", function() {
            var switchState = this.checked ? "on" : "off";
            var dataId = this.getAttribute("data-id");
            var data = {
                "switch": switchState,
                "id": dataId
            };
            
            console.log(dataId);
            
            fetch("fetch-data/food-status.php", {
                method: "POST",
                body: JSON.stringify(data),
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then((data) => {
                console.log(data);
            });
        });
    });
});

</script>