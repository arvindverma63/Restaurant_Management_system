fetch('fetch-data/select-category.php')
    .then(response => response.json())
    .then(data => {
        console.log(data);
        const selectElement = document.getElementById('select-cat');
        
        // Clear existing options
        selectElement.innerHTML = '';
        
        // Create and append new options
        data.forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.text = category;
            selectElement.appendChild(option);
        });
    })
    .catch(error => {
        console.error('Error:', error);
    });
