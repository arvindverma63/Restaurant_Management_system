document.getElementById('submit-menu-category').addEventListener('click', function(event) {
    event.preventDefault();

    const categoryName = document.getElementById('menu-category').value;
    const menuImage = document.getElementById('menu-image').files[0]; // Get the file object

    if (!categoryName || !menuImage) {
        alert('Category name or image is missing.');
        return;
    }

    const formData = new FormData();
    formData.append('categoryName', categoryName);
    formData.append('menuImage', menuImage);

    fetch('fetch-data/add-menu-category.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data);
        if (data.status === 'success') {
            alert('Menu category added successfully');
            document.getElementById('category').reset(); // Reset form if needed
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
    });
});
