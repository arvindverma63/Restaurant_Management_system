document.getElementById("add-item").addEventListener("click", function() {
  // Get form values
  const category = document.getElementById('select-cat').value;
  const itemName = document.getElementById('item_name').value;
  const price = document.getElementById('price').value;
  const itemImage = document.getElementById('item_image').files[0];

  // Validate inputs
  if (!category || !itemName || !price || !itemImage) {
      alert("All fields are required.");
      return;
  }

  // Create a FormData object and append form data
  const formData = new FormData();
  formData.append('category', category);
  formData.append('item_name', itemName);
  formData.append('price', price);
  formData.append('item_image', itemImage);

  // Send the form data using Fetch API
  fetch('fetch-data/insert-menu.php', {
      method: 'POST',
      body: formData,
      headers: {
          'Content-Type': 'application/json'
      }
  })
  .then(response => {
      if (!response.ok) {
          throw new Error('Network response was not ok ' + response.statusText);
      }
      return response.json();
  })
  .then(data => {
      console.log(data);
      if (data.status === 'success') {
          alert('Item added successfully!');
          // Optionally, redirect to another page
          // window.location.href = "index.php";
      } else {
          alert('Error: ' + data.message);
      }
  })
});
