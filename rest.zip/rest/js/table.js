document.getElementById("add-table").addEventListener("click", function() {
    var table_num = document.getElementById("table-num").value;
    fetch("fetch-data/add-table.php", {
        method: "POST",
        body: JSON.stringify({ table_num: table_num }),
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data);
        window.location.href = "index.php";
    })
    .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
    });
});
